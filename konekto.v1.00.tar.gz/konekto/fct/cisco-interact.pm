$cnx->expect('-re',$prompt); $cnx->send("terminal length 0\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->expect('-re',$prompt); $cnx->send("show ip interface brief\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->expect('-re',$prompt); $cnx->send("show debug\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->expect('-re',$prompt); $cnx->send("terminal length 50\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");

$cnx->interact(); 

1;
