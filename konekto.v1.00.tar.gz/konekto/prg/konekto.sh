#!/bin/bash

# version  : 1.00 - January 2024
# author   : Thierry Le Gall
# contact  : facila@gmx.fr
# web site : https://github.com/facila/konekto

# commande : konekto.sh ADDRESS [OPTIONS]
# OPTIONS  : synthaxe identique à celle de konekto.pl
# USERNAME et PASSWORD sont recherchés dans $VAR/user
# exécution de konekto.pl COMMAND

# pour une définition de USERNAME , PASSWORD , LOGIN , PROMPT_READ , PROMPT_WRITE et FUNCTION correspondants à d'autres critères 
# - copier konekto.sh en "myscript.sh"
# - adapter la recherche de USERNAME et PASSWORD à votre environnement
# - adapter la recherche de LOGIN , PROMPT_READ , PROMPT_WRITE si besoin
# - ajouter des FUNCTION et leurs fichiers associés si besoin
# - modifier les paramètres de l'appel à konekto.pl en conséquence

PRG=$FACILA/konekto/prg
VAR=$FACILA/konekto/var/$LANG

[ "$1" = '-h' ] && { cat $VAR/help ; exit ; }

USERNAME=`grep username $VAR/user | cut -f2 -d';'`
PASSWORD=`grep password $VAR/user | cut -f2 -d';'`

COMMAND="$* -u $USERNAME -p $PASSWORD"

$PRG/konekto.pl $COMMAND
