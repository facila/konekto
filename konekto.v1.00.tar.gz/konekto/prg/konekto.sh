#!/bin/bash

# version  : 1.00 - January 2024
# author   : Thierry Le Gall
# contact  : facila@gmx.fr
# web site : https://github.com/facila/konekto

# commande : konekto.sh ADDRESS 
# USERNAME et PASSWORD sont recherchés dans $VAR/user
# exécution de konekto.pl ssh ADDRESS USERNAME PASSWORD

# pour une définition de LOGIN , USERNAME , PASSWORD et FUNCTION correspondants à d'autres critères 
# - copier konekto.sh en "myscript.sh"
# - adapter la recherche de LOGIN , USERNAME et PASSWORD à votre environnement
# - ajouter des FUNCTION et leurs fichiers associés si besoin

DIR=$FACILA/konekto
VAR=$DIR/var/$LANG

[ "$1" = '-h' ] && { cat $VAR/help ; exit ; }

   LOGIN=ssh
 ADDRESS=$1
USERNAME=`grep username $VAR/user | cut -f2 -d';'`
PASSWORD=`grep password $VAR/user | cut -f2 -d';'`
FUNCTION=''

$DIR/prg/konekto.pl $LOGIN $ADDRESS $USERNAME $PASSWORD $FUNCTION
