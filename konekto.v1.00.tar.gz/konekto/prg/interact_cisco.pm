# version  : 1.00 - January 2024
# author   : Thierry Le Gall
# contact  : facila@gmx.fr
# web site : https://github.com/facila/konekto

# le script appelant la fonction doit initialiser :
# - use Expect
#   $cnx = new Expect;
# - les variables sont globales : cnx , prompt
 
# commandes cisco
$cnx->expect($prompt); $cnx->send("terminal length 0\n");
$cnx->expect($prompt); $cnx->send("\n");
$cnx->expect($prompt); $cnx->send("show ip interface brief\n");
$cnx->expect($prompt); $cnx->send("\n");
$cnx->expect($prompt); $cnx->send("show debug\n");
$cnx->expect($prompt); $cnx->send("\n");
$cnx->expect($prompt); $cnx->send("terminal length 50\n");
$cnx->expect($prompt); $cnx->send("\n");

$cnx->interact(); 

1;
