#!/bin/bash

# XTERM par défaut

 BG=black
 FG=white
 FN=-*-fixed-*-*-*-*-15-*-*-*-*-*-*-*
GEO=120x40+100+100

XTERM="-geometry $GEO -bg $BG -fg $FG -fn $FN"
