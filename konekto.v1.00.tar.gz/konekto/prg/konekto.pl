#!/usr/bin/perl

# version  : 1.00 - January 2024
# author   : Thierry Le Gall
# contact  : facila@gmx.fr
# web site : https://github.com/facila/konekto

# script perl avec l'utilisation de Expect.pm

# commande : konekto.pl ADDRESS -u USERNAME -p PASSWORD -l LOGIN -pr PROMPT_READ -pw PROMPT_WRITE -f FUNCTION -h

# options :
# -u  USERNAME
# -p  PASSWORD
# -l  LOGIN        : valeur par défaut : ssh      - autre : ssh ou telnet ou telnet_user
# -pr PROMPT_READ  : valeur par défaut : >
# -pw PROMPT_WRITE : valeur par défaut : # 
# -f  FUNCTION     : valeur par défaut : interact - autre : exécution de "FUNCTION".pm
# -h               : affichage de l'aide

# la commande de connexion correspondant à LOGIN est définie dans $var/login
# vous pouvez en ajouter avec de nouveaux modes ou de nouvelles options 

# vous pouvez créer des FUNCTION avec les commandes de Expect correspondant à votre environnement

$facila = $ENV{FACILA};
$lang   = $ENV{LANG};
$dir    = "$facila/konekto";
$var    = "$dir/var/$lang";

$login        = 'ssh';
$prompt_read  = '>';
$prompt_write = '#';

use Getopt::Long qw(GetOptions);
GetOptions('u=s'=>\$username, 'p=s' =>\$password,
           'l=s'=>\$login   , 'pr=s'=>\$prompt_read, 'pw=s'=>\$prompt_write,
           'f=s'=>\$function, 'h'   =>\$help);

($address) = @ARGV;

if ( $help ) { print `cat $var/help`; exit }

use Expect;
$cnx = new Expect;

chomp($spawn = `grep "$login *;" $var/login | cut -f2 -d';'`);
$spawn =~ s/<(.*?)>/$$1/g;
$cnx = Expect->spawn("$spawn");

$prompt = $prompt_write;
if    ( $login =~ /ssh|telnet_user/ ) { $cnx->expect("Password:"); $cnx->send("$password\n") }
elsif ( $login eq 'telnet' ) {
      $cnx->expect("Password:"); $cnx->send("$username\n"); # username est le password pour RO 
      $prompt = $prompt_read;
      if ( $password ne '' ) {
         $cnx->expect($prompt)    ; $cnx->send("enable\n");
         $cnx->expect("Password:"); $cnx->send("$password\n"); # password est le password pour RW
         $prompt = $prompt_write } }

if ( ! $function ) { $cnx->interact() } 
else { require "$dir/prg/$function.pm" }
