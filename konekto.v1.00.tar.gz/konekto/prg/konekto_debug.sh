#!/bin/bash

# version  : 1.00 - January 2024
# author   : Thierry Le Gall
# contact  : facila@gmx.fr
# web site : https://github.com/facila/konekto

# commande : konekto_debug.sh ["XTERM"] 
# XTERM    : couleurs , police et taille du terminal 

# exécution dans une fenêtre xterm de la connexion d'un autre utilisateur avec la possibilité de l'utiliser ensemble

# affichage de la liste des connexion en cours
# sélection d'une connexion
# ouverture du terminal

DIR=$FACILA/konekto
cd $DIR/tmp

LIST=`ls -1 *.out 2>/dev/null`
if [ "$LIST" = '' ]
then printf "aucune connexion en cours\n"
     exit
fi

# affichage de la liste des connexion en cours
X=0
echo
echo "$LIST" | while read OUT
do X=`expr $X + 1` 
   printf " %2s %-s\n" $X $OUT
done

# sélection d'une connexion
printf "\n numéro de la connexion à debuguer : "
read Y
echo
[ "$Y" = '' ] && exit

# OUT et IN fichiers de la connexion utilisés en commun
FILE=`echo "$LIST" | head -n$Y | tail -1`
 OUT="$DIR/tmp/$FILE"
  IN=`echo $OUT | sed s/out$/in/`
COMMAND="stty -echo -icanon ; cat >> $IN | tail -n+1 -f $OUT"

. $DIR/prg/default_xterm.sh
[ "$1" != '' ] && XTERM="$XTERM $1" 

# ouverture du terminal
xterm -title "DEBUG $FILE" $XTERM -e "$COMMAND" &
