#!/bin/bash

# version : 1.00 Janvier 2024
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : konekto_xterm.sh NAME "KONEKTO" ["XTERM"]
# NAME     : nom de l'équipement
# KONEKTO  : paramètres de konekto.pl : LOGIN ADDRESS USERNAME PASSWORD FUNCTION
# XTERM    : couleurs , police et taille de la fenêtre

# exécution de la connexion konekto.pl KONEKTO dans une fenêtre xterm
# - avec 2 fichiers temporaires $OUT et $IN
# - $OUT permet à partir d'autres scripts de suivre le résultat des commandes d'une FUNCTION et d'agir en conséquence
# - $OUT permet de sauvegarder la connexion
# - $IN  permet à d'autres utilisateurs d'utiliser la même connexion

if [ "$1" = 'PROG' ]
then NAME=$2
     shift ; shift
     DIR=$FACILA/konekto
     TMP=$DIR/tmp/$NAME.$USER.$$
     OUT=$TMP.out ; touch $OUT ; chmod 666 $OUT
     IN=$TMP.in   ; touch $IN  ; chmod 666 $IN
     PID=$TMP.pid ; touch $PID ; chmod 666 $PID
     trap 'rm -f $TMP* ; exit' 1 2 9

     stty -echo -icanon
     {
     tail -f $IN --pid $$ &
     cat &
     printf "$!" > $PID # pour le kill de cat
     } | $DIR/prg/konekto.pl $* | tee -a $OUT

     # sauvegarde de konekto
     SAVE=`tail -5 $OUT | grep '! save'`
     [ "$SAVE" != "" ] && cp $OUT $FACILA/save/konekto/$NAME.`date +%y-%m-%d.%H-%M`

     kill -9 `cat $PID`
     rm -f $TMP*
     stty echo icanon
     printf "\nAppuyer sur Entrée pour terminer ..."
     read
     exit
fi

. $FACILA/share/prg/def_xterm.sh

NAME=$1
KONEKTO=$2
[ "$3" != '' ] && XTERM="$XTERM $3"

xterm -title "KONEKTO $NAME" $XTERM -e "$0 PROG $NAME $KONEKTO"
