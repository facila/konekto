#!/bin/bash

# version : 1.10 Juin 2025
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : konekto.sh ADDRESS USERNAME 
# LOGIN = ssh
# PASSWORD est recherché dans $VAR/user
# FUNCTION est vide
# exécution de konekto.pl LOGIN ADDRESS USERNAME PASSWORD FUNCTION

# pour une définition de LOGIN , USERNAME , PASSWORD et FUNCTION correspondants à d'autres critères 
# - copier konekto.sh en "myscript.sh"
# - adapter la recherche de LOGIN , USERNAME et PASSWORD à votre environnement
# - ajouter des FUNCTION et leurs fichiers associés si besoin

DIR=$FACILA/konekto
VAR=$DIR/var/$LANG

[ "$1" = '-h' ] && { cat $VAR/help ; exit ; }

   LOGIN=ssh
 ADDRESS=$1
USERNAME=$2
PASSWORD=''
FUNCTION=''

[ "$USERNAME" != '' ] && PASSWORD=`grep "^$USERNAME;" $VAR/user | cut -f2 -d';'` 

$DIR/prg/konekto.pl $LOGIN $ADDRESS $USERNAME $PASSWORD $FUNCTION
