#!/usr/bin/perl -w

# fct_block.pl version 1.32 Juin 2025 par Thierry Le Gall
#
# rechercher les fichiers d'un dossier contenus dans un fichier
#
# syntaxe :
# fct_block.pl FILE DIR EXCLUDE
# FILE    = fichier à analyser
# DIR     = dossier contenant les fichiers à rechercher
# EXCLUDE = chaine à exclure des fichiers

use strict;
require "$ENV{FACILA}/share/prg/fct_block.pm";

my($file,$dir,$exclude) = @ARGV;
my(%source,%block,%result,%include,%double);

# création d'un tableau contenant les lignes du fichier à analyser
open(FILE,$file); while(<FILE>) { chomp; $source{$_} = 1 } close FILE;

fct_block_dir(\%block,$dir,$exclude);                    # création du tableau %block
fct_block(\%source,\%block,\%result,\%include,\%double); # recherche des blocks 

foreach(sort {$a cmp $b} keys %result ) { print "b:$_\n" } # block
foreach(sort {$a cmp $b} keys %include) { print "i:$_\n" } # include
foreach(sort {$a cmp $b} keys %double ) { print "d:$_\n" } # double
foreach(sort {$a cmp $b} keys %source ) { print "e:$_\n" } # error
