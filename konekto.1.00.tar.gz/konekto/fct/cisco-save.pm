$cnx->expect('-re',$prompt); $cnx->send("copy running-config startup-config\n");
$cnx->expect(']?')         ; $cnx->send("\n");
$cnx->expect('-re',$prompt);

1;
