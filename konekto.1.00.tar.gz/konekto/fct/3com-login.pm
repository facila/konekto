$cnx->expect('-re',$prompt); $cnx->send("screen-length 0\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->expect('-re',$prompt); $cnx->send("display brief interface\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->expect('-re',$prompt); $cnx->send("display debugging\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->expect('-re',$prompt); $cnx->send("screen-length 24\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->interact(); 

1;
