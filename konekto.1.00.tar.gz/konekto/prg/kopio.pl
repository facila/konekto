#!/usr/bin/perl

# version  : 1.00 - January 2024
# author   : Thierry Le Gall
# contact  : facila@gmx.fr
# web site : https://github.com/facila/konekto

# commande : kopio.pl COPY SOURCE TARGET PASSWORD
# exemple  : kopio.pl scp admin@192.168.1.254:startup-config "dir/file" "password"
# exemple  : kopio.pl scp "dir/file" admin@192.168.1.254:running-config "password"

# script perl avec utilisation du module Expect.pm
# COPY est défini dans $var/command

$var = "$ENV{FACILA}/konekto/var/$ENV{LANG}";

($copy,$source,$target,$password)= @ARGV;

chomp($command = `grep "^$copy;" $var/command | cut -f3 -d';'`);
$command =~ s/<(.*?)>/$$1/g;

use Expect;
$cnx = new Expect;
$cnx = Expect->spawn("$command");
$cnx->expect('Password');
$cnx->send("$password\n");
$cnx->expect('X');
