#!/bin/bash

DEF=$FACILA/share/data/default	
BG=`grep bg.main $DEF | cut -f3 -d';'`
FG=`grep fg.main $DEF | cut -f3 -d';'`
FN=`grep fn.main $DEF | cut -f3 -d';'`
GO=`grep go.main $DEF | cut -f3 -d';'`

XTERM="-geometry $GO -bg $BG -fg $FG -fn $FN"
