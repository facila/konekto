#!/bin/bash

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : sendo_xterm.sh "XTERM" FUNCTION NAME PARAMETRES
# XTERM    : paramétres xterm : couleurs , police et taille de la fenêtre

   XTERM=$1 ; shift
FUNCTION=$1
    NAME=$2

case $FUNCTION in
  run) TITRE="TELECHARGER EN RUNNING" ;;
start) TITRE="TELECHARGER EN STARTUP" ;;
 save) TITRE="SAUVEGARDER"            ;;
    *) exit ;;
esac 

xterm -title "$TITRE $NAME" $XTERM -e "$FACILA/konekto/prg/sendo.sh $*"
