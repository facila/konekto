#!/bin/bash

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# script de sauvegarde et de téléchargement d'équipements réseau fonctionnant en mode running et startup
# utilisé dans l'outil reto de gestion de d'équipements réseau
# $1 = SAVE  : sauvegarde de la configuration dans l'équipement + puis sur le serveur :          "KONEKTO" "KOPIO2" 
# $1 = RUN   : téléchargement d'une configuration en running + sauvegarde ( save )    : "KOPIO1" "KONEKTO" "KOPIO2"
# $1 = START : téléchargement d'une configuration en startup + reboot ?               : "KOPIO1" "KONEKTO"

# commande : sendo.sh FUNCTION NAME ["KOPIO1"] ["KONEKTO"] ["KOPIO2"] ["XTERM"]
# exécution de sendo.sh , dans une fenêtre xterm si XTERM
# $1 = FUNCTION : save , run ou start en minuscules avec XTERM
# $1 = FUNCTION : SAVE , RUN ou START en majuscules sans XTERM
# $2 = NAME     : nom de l'équipement pour le titre de xterm
# $2 = KOPIO1   : paramètre de kopio.pl   :
# $3 = KONEKTO  : paramètre de konekto.pl :
# $4 = KOPIO2   : paramètre de kopio.pl   :
# $6 = XTERM    : couleurs , police et taille de la fenêtre

PATH=$PATH:$FACILA/konekto/prg
FUNCTION=$1
NAME=$2

##################### avec xterm ######################################
case $FUNCTION in
save|run|start)
   case $FUNCTION in
  save) TITRE="SAUVEGARDER "            ; COMMAND="SAVE  $NAME \"$3\" \"$4\""        ; [ "$5" != '' ] && XTERM=$5 ;;
   run) TITRE="TELECHARGER EN RUNNING " ; COMMAND="RUN   $NAME \"$3\" \"$4\" \"$5\"" ; [ "$6" != '' ] && XTERM=$6 ;;
 start) TITRE="TELECHARGER EN STARTUP " ; COMMAND="START $NAME \"$3\""               ; [ "$4" != '' ] && XTERM=$4 ;;
   esac 
   xterm -title "$TITRE $NAME" $XTERM -e "$0 $COMMAND"
   exit ;;
esac

##################### sans xterm ######################################
proc_fin ()
{
printf $SEPAR
printf "Appuyer sur Entrée pour terminer ..."
read
exit
}

proc_kopio ()
{
COPY=$1
SOURCE=$2
TARGET=$3
INFO=''
INFO+=" équipement  : $NAME\n"
INFO+=" serveur     : $HOST\n"
INFO+=" copie       : $COPY\n"
INFO+=" source      : $SOURCE\n"
INFO+=" destination : $TARGET\n"
}

HOST=`hostname`
for I in $(seq 1 100) ; do SEPAR=$SEPAR"~" ; done
SEPAR="\n$SEPAR\n"

case $FUNCTION in RUN|START)
     proc_kopio $3
     cat $SOURCE

     printf "\n$SEPAR"
     printf "Voulez-vous télécharger l'équipement :\n\n"
     printf "$INFO"
     printf "\n (o) pour oui ? "
     read OK
     [ "$OK" != 'o' ] && proc_fin

     printf $SEPAR
     printf "Téléchargement de l'équipement :\n"
     kopio.pl $3
     shift ;;
esac

case $FUNCTION in RUN)
     printf $SEPAR ;;
esac

case $FUNCTION in SAVE|RUN)
     printf "Sauvegarde dans l'équipement :\n"
     konekto.pl $3

     printf "\n$SEPAR"
     proc_kopio $4
     printf "Sauvegarde sur le serveur :\n\n"
     printf "$INFO"
     kopio.pl $4 ;;
esac

case $FUNCTION in START)
     printf $SEPAR
     printf "Voulez-vous rebooter l'équipement :\n\n"
     printf " (o) pour oui ? "
     read OK
     [ "$OK" != 'o' ] && proc_fin
     #konekto.pl $3
     ;;	
esac

proc_fin
