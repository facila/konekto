#!/bin/bash

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# sauvegarde et de téléchargement d'équipements réseau fonctionnant en mode running et startup
# utilisé dans l'outil reto de gestion d'équipements réseau

# commande : sendo.sh FUNCTION NAME USER DATA MARK SOURCE COPY LOGIN ADDRESS USERNAME PASSWORD

# FUNCTION = save  : sauvegarde de la configuration dans l'équipement + puis sur le serveur
# FUNCTION = run   : téléchargement d'une configuration en running + sauvegarde ( save )
# FUNCTION = start : téléchargement d'une configuration en startup

proc_fin ()
{
printf $SEPAR
printf "Appuyer sur Entrée pour terminer ..."
read
exit
}

proc_info ()
{
INFO=''
INFO+=" équipement  : $NAME\n"
INFO+=" serveur     : $HOST\n"
INFO+=" copie       : $COPY\n"
INFO+=" source      : $SOURCE\n"
INFO+=" destination : $TARGET\n"
}

proc_load ()
{
cat $SOURCE

printf "\n$SEPAR"
printf "Voulez-vous télécharger l'équipement :\n\n"
proc_info
printf "$INFO"
printf "\n (o) pour oui ? "
read OK
[ "$OK" != 'o' ] && proc_fin

printf $SEPAR
printf "Téléchargement de l'équipement :\n"
kopio.pl $COPY $SOURCE $TARGET $PASSWORD

printf $SEPAR
printf "Sauvegarde du téléchargement :\n\n"
DATE=`date "+%Y-%m-%d.%H-%M-%S"`
SAVE="$DATA/load/$NAME.$USER.$DATE"
printf " $SAVE\n"
cp $SOURCE $SAVE
}

save ()
{
COMMAND=$FACILA/konekto/data/$MARK/save
[ ! -f $COMMAND ] && exit

printf "Sauvegarde dans l'équipement :\n"
konekto.pl $LOGIN $ADDRESS $USERNAME $PASSWORD $COMMAND

printf "\n$SEPAR"
SOURCE=$USERNAME@$ADDRESS:$START
TARGET=$DATA/conf/$NAME

# sauvegarde de l'ancienne configuration
DATE=`date "+%Y-%m-%d.%H-%M-%S"`
SAVE=$DATA/save/$NAME.$USER.$DATE
cp $TARGET $SAVE

proc_info
printf "Sauvegarde sur le serveur :\n\n"
printf "$INFO"
kopio.pl $COPY $SOURCE $TARGET $PASSWORD

printf $SEPAR
if [ "`diff $TARGET $SAVE`" = '' ]
then printf "Pas de sauvegarde de l'ancienne configuration car elle est identique\n"
     rm $SAVE
else printf "Sauvegarde de l'ancienne configuration :\n\n"
     printf " $SAVE\n"
fi
}

run ()
{
TMP=`basename $SOURCE`
TARGET=$USERNAME@$ADDRESS:$TMP
proc_load

printf $SEPAR
printf "Application de la configuration :\n"
COMMAND=$SOURCE.cmd
cmd_load_run.sh $MARK $TMP > $COMMAND
konekto.pl $LOGIN $ADDRESS $USERNAME $PASSWORD $COMMAND

# Sauvegarde
printf $SEPAR
save
}

start ()
{
TARGET=$USERNAME@$ADDRESS:$START
proc_load
}

HOST=`hostname`
for I in $(seq 1 100) ; do SEPAR=$SEPAR"~" ; done
SEPAR="\n$SEPAR\n"

PATH=$PATH:$FACILA/konekto/prg
FUNCTION=$1 ; shift
NAME=$1     ; shift
USER=$1     ; shift
DATA=$1     ; shift
MARK=$1     ; shift

SOURCE=$1
COPY=$2
LOGIN=$3
ADDRESS=$4
USERNAME=$5
PASSWORD=$6

START=`cat $FACILA/konekto/data/$MARK/start`

printf $SEPAR
$FUNCTION
proc_fin
