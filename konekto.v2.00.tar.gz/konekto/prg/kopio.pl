#!/usr/bin/perl

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : kopio.pl FUNCTION SOURCE TARGET PASSWORD
# exemple  : kopio.pl scp admin@192.168.1.254:startup-config "dir/file" "password"
# exemple  : kopio.pl scp "dir/file" admin@192.168.1.254:running-config "password"

# script perl avec utilisation du module Expect.pm
# COPY est défini dans data/config

chdir "$ENV{FACILA}/konekto/data";

($function,$source,$target,$password) = @ARGV;

chomp($copy = `grep "^$function;" config | cut -f3 -d';'`);

# remplacement des variables par leurs valeurs dans $copy
$copy =~ s/<(.*?)>/$$1/g;

use Expect;
$cnx = new Expect;
$cnx = Expect->spawn("$copy");
$cnx->log_stdout(0); # suppression de l'affichage
$cnx->expect('-re','(?i)Password');
$cnx->send("$password\n");
$cnx->log_stdout(1); # retour de l'affichage
$cnx->expect('X');
