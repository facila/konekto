#!/bin/bash

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : konekto.sh "CONFIRM" "NAME" "KONEKTO"
# CONFIRM  : message de confirmation de l'opération
# NAME     : nom de l'équipement
# KONEKTO  : paramètres de konekto.pl : FUNCTION ADDRESS USERNAME PASSWORD COMMAND

# exécution de la connexion konekto.pl KONEKTO
# - avec 2 fichiers temporaires $OUT et $IN
# - $OUT permet à partir d'autres scripts de suivre le résultat des commandes et d'agir en conséquence
# - $OUT permet de sauvegarder la connexion
# - $IN  permet à d'autres utilisateurs d'utiliser la même connexion

proc_fin ()
{
printf "\nAppuyer sur Entrée pour terminer ..."
read
exit
}

CONFIRM=$1
if [ "$CONFIRM" != '' ]
then printf "$CONFIRM\n\n"
     printf " (o) pour oui ? "
     read OK
     [ "$OK" != 'o' ] && proc_fin
fi

NAME=$2
shift ; shift
DIR=$FACILA/konekto
TMP=$DIR/tmp/$NAME.$USER.$$
OUT=$TMP.out ; touch $OUT ; chmod 660 $OUT
 IN=$TMP.in  ; touch $IN  ; chmod 660 $IN
PID=$TMP.pid ; touch $PID ; chmod 660 $PID
trap 'rm -f $TMP* ; exit' 1 2 9

stty -echo -icanon
{
tail -f $IN --pid $$ &
cat &
printf "$!" > $PID # pour le kill de cat
} | $DIR/prg/konekto.pl $* | tee -a $OUT

# sauvegarde de konekto
SAVE=`tail -5 $OUT | grep '! save'`
[ "$SAVE" != "" ] && cp $OUT $FACILA/save/konekto/$NAME.`date +%y-%m-%d.%H-%M`

kill -9 `cat $PID`
rm -f $TMP*
stty echo icanon
printf "\n"
proc_fin
