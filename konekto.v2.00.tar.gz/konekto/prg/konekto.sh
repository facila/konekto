#!/bin/bash

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : konekto.sh ADDRESS USERNAME 
# FUNCTION : ssh
# PASSWORD : est recherché dans data/user
# COMMAND  : est vide
# exécution de : konekto.pl FUNCTION ADDRESS USERNAME PASSWORD COMMAND

# pour une définition de FUNCTION , USERNAME , PASSWORD et COMMAND correspondants à d'autres critères 
# - copier konekto.sh en "myscript.sh"
# - adapter la recherche de FUNCTION , USERNAME et PASSWORD à votre environnement
# - ajouter des COMMAND et leurs fichiers associés si besoin

DIR=$FACILA/konekto
cd $DIR/data

[ "$1" = '-h' ] && { cat help ; exit ; }

FUNCTION=ssh
 ADDRESS=$1
USERNAME=$2
PASSWORD=''
 COMMAND=''

[ "$USERNAME" != '' ] && PASSWORD=`grep "^$USERNAME;" user | cut -f2 -d';'` 

$DIR/prg/konekto.pl $FUNCTION $ADDRESS $USERNAME $PASSWORD $COMMAND
