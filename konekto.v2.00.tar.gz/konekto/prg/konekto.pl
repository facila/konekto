#!/usr/bin/perl

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : konekto.pl FUNCTION ADDRESS USERNAME PASSWORD [COMMAND]
# exemple  : konekto.pl ssh 192.168.1.254 admin "password"

# commande de login automatique
# script perl avec utilisation du module Expect.pm

# PROMPT , LOGIN et MODE correspondant à FUNCTION sont définis dans data/config
# vous pouvez créer des fonctions de login avec de nouveaux modes ou de nouvelles options

# COMMAND est optionel et à plusieurs formats pour envoyer des commandes
# vous pouvez créer des commandes correspondant à votre environnement
# - un fichier de commandes dans data
# - des commandes numérotées xxxx dans data/command
# - une liste de commandes séparées par des ;

($function,$address,$username,$password,$command) = @ARGV;

chdir "$ENV{FACILA}/konekto/data";
if ( $function eq '-h' ) { print `cat help`; exit }

$timeout = 20;

chomp($prompt = `grep "^prompt;"    config | cut -f3 -d';'`);
chomp($login  = `grep "^$function;" config | cut -f3 -d';'`);
chomp($mode   = `grep "^$function;" config | cut -f5 -d';'`);

# remplacement des variables par leurs valeurs dans $login
$login =~ s/<(.*?)>/$$1/g;

use Expect;
$cnx = new Expect;
$cnx = Expect->spawn("$login");

# suppression de l'affichage
$cnx->log_stdout(0);

# login username password , option (?i) pour majuscules ou minuscules
if    ( $mode eq 'username' ) {
      $cnx->expect('-re','(?i)username'); $cnx->send("$username\n"); 
      $cnx->expect('-re','(?i)password'); $cnx->send("$password\n") }
elsif ( $mode eq 'password' ) {
      $cnx->expect('-re','(?i)password'); $cnx->send("$password\n") }
elsif ( $mode eq 'enable' ) {
      $cnx->expect('-re','(?i)password')  ; $cnx->send("$username\n");  # username est le password 1 pour enable
      $cnx->expect('-re',$prompt)         ; $cnx->send("enable\n");
      $cnx->expect('-re','(?i)password')  ; $cnx->send("$password\n") } # password est le password 2 pour enable
$cnx->expect('-re',$prompt);

# determination du prompt complet
$cnx->send("\n");
$cnx->expect('-re',$prompt);
$match  = $cnx->match();
$before = $cnx->before();
$before =~ tr/\r\n//d;
$prompt = $before.$match;

if ( ! $command || -f $command ) {
   # retour de l'affichage
   $cnx->log_stdout(1);
   $cnx->send("\n");
   $cnx->expect($timeout,$prompt);
   # exécution des commandes du fichier $command
   if ( -f $command ) {
      foreach(`cat $command`) {
         next if /^#/;
         chomp;
         ( $send , $expect ) = split/;/;
         exit if $send eq 'konekto_end'; # cas avec fin du login
         $expect = $prompt if ! $expect;
         $cnx->send("$send\n");
         $cnx->expect($timeout,$expect) } }
   # cas avec login maintenu
   $cnx->interact }

# exécution des commandes et fin du login
elsif ( $command ) {
   for ( 1 .. 140 ) { $separ .= '~' }
   # commandes si xxxx a partir du fichier data/command
   if ( $command =~ /^\d+$/ ) { $command = `grep "^$command;" command | cut -f2- -d';'` }
   foreach $send ( split /;/ , $command ) {
      $cnx->send("$send\n");
      $cnx->expect($timeout,$prompt);
      $before = $cnx->before();
      $before =~ s/^[^\n]*\n//; # supp première ligne , la commande
      if ( $before ) {
         $i++;
         $output .= "\n$separ\n" if $i > 1; 
         $output .= $before } }
   print $output }
