#!/bin/bash

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# exécution de konekto.sh dans une fenêtre xterm

# commande : konekto_xterm.sh "XTERM" "CONFIRM" NAME "KONEKTO"
# XTERM    : couleurs , police et taille de la fenêtre
# CONFIRM  : message de confirmation de l'opération
# NAME     : nom de l'équipement
# KONEKTO  : paramètres de konekto.sh : FUNCTION ADDRESS USERNAME PASSWORD COMMAND

XTERM=$1   ; shift
CONFIRM=$1 ; shift
NAME=$1

xterm -title "KONEKTO $NAME" $XTERM -e "$FACILA/konekto/prg/konekto.sh \"$CONFIRM\" $*"
