#!/usr/bin/perl

# version : 1.10 Juin 2025
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : konekto.pl LOGIN ADDRESS USERNAME PASSWORD [FUNCTION]
# exemple  : konekto.pl ssh 192.168.1.254 admin "password"

# script perl avec utilisation du module Expect.pm
# le PROMPT , la COMMAND et le MODE de connexion correspondant à LOGIN sont définis dans $var/command
# vous pouvez créer des commandes avec de nouveaux modes ou de nouvelles options
# vous pouvez créer des functions avec les commandes de Expect correspondant à votre environnement

$dir = "$ENV{FACILA}/konekto";
$var = "$dir/var/$ENV{LANG}";

if ( $ARGV[0] eq '-h' ) { print `cat $var/help`; exit }

($login,$address,$username,$password,$function) = @ARGV;

chomp($prompt  = `grep "^prompt;" $var/command | cut -f3 -d';'`);
chomp($command = `grep "^$login;" $var/command | cut -f3 -d';'`);
chomp($mode    = `grep "^$login;" $var/command | cut -f5 -d';'`);

# remplacement des variables par leurs valeurs dans $command
$command =~ s/<(.*?)>/$$1/g;

use Expect;
$cnx = new Expect;
$cnx = Expect->spawn("$command");

# option (?i) pour majuscules ou minuscules
if    ( $mode eq 'username' ) {
      $cnx->expect('-re','(?i)username'); $cnx->send("$username\n"); 
      $cnx->expect('-re','(?i)password'); $cnx->send("$password\n") }
elsif ( $mode eq 'password' ) {
      $cnx->expect('-re','(?i)password'); $cnx->send("$password\n") }
elsif ( $mode eq 'enable' ) {
      $cnx->expect('-re','(?i)password')  ; $cnx->send("$username\n");  # username est le password 1 pour enable
      $cnx->expect('-re',$prompt)         ; $cnx->send("enable\n");
      $cnx->expect('-re','(?i)password')  ; $cnx->send("$password\n") } # password est le password 2 pour enable

# exécution des fonctions 
$function = '' if ! -f "$dir/fct/$function.pm";
if    ( ! $function          ) { $cnx->interact() } 
elsif (   $function ne 'end' ) { require "$dir/fct/$function.pm" }
