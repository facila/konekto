#!/usr/bin/perl

# version : 1.10 Juin 2025
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/konekto

# commande : kopio.pl COPY SOURCE TARGET PASSWORD
# exemple  : kopio.pl scp admin@192.168.1.254:startup-config "dir/file" "password"
# exemple  : kopio.pl scp "dir/file" admin@192.168.1.254:running-config "password"

# script perl avec utilisation du module Expect.pm
# COPY est défini dans $var/command

$var = "$ENV{FACILA}/konekto/var/$ENV{LANG}";

($copy,$source,$target,$password)= @ARGV;

chomp($command = `grep "^$copy;" $var/command | cut -f3 -d';'`);

# remplacement des variables par leurs valeurs dans $command
$command =~ s/<(.*?)>/$$1/g;

use Expect;
$cnx = new Expect;
$cnx = Expect->spawn("$command");
$cnx->expect('-re','(?i)Password');
$cnx->send("$password\n");
$cnx->expect('X');
