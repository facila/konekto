$cnx->expect('-re',$prompt); $cnx->send("reload\n");
$cnx->expect('-re',$prompt); $cnx->send("\n");
$cnx->expect('-re',$prompt);

1;
